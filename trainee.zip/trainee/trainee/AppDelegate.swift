import UIKit
import Firebase
import FirebaseUI
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    var auth: FUIAuth?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        self.configureDependencies()
        self.startAppFlow()
        return true
    }
    private func configureDependencies() {
        FirebaseApp.configure()
        self.auth = FUIAuth.defaultAuthUI()
        self.auth?.delegate = self
        self.auth?.providers = [FUIEmailAuth()]
    }
    private func startAppFlow() {
        self.window = UIWindow()
        guard let splash = R.storyboard.main.gifVC() else {return}
        splash.completionHandler = { [unowned self] in
            guard let authVC = self.auth?.authViewController() else { fatalError() }
            authVC.modalPresentationStyle = .fullScreen
            self.window?.rootViewController?.present(authVC, animated: true)
        }
        self.window?.rootViewController = splash
        self.window?.makeKeyAndVisible()
    }
}

extension AppDelegate: FUIAuthDelegate {
    func emailEntryViewController(forAuthUI authUI: FUIAuth) -> FUIEmailEntryViewController {
        return EmailViewController(nibName: nil,bundle: nil,authUI: authUI)
    }
    func passwordSignInViewController(forAuthUI authUI: FUIAuth, email: String) -> FUIPasswordSignInViewController {
        return PasswordSignInViewController(nibName: nil,bundle: nil,authUI: authUI,email: email)
    }
    func authPickerViewController(forAuthUI authUI: FUIAuth) -> FUIAuthPickerViewController {
        return PickerViewController(nibName: nil,bundle: nil,authUI: authUI)
    }
    func passwordSignUpViewController(forAuthUI authUI: FUIAuth, email: String) -> FUIPasswordSignUpViewController {
        return SignUpViewController(nibName: nil,bundle: nil,authUI: authUI, email: email)
    }
    func passwordRecoveryViewController(forAuthUI authUI: FUIAuth, email: String) -> FUIPasswordRecoveryViewController {
        return PasswordRecoveryViewController(nibName: nil, bundle: nil, authUI: authUI, email: email)
    }
    func authUI(_ authUI: FUIAuth, didSignInWith authDataResult: AuthDataResult?, error: Error?) {
        if error == nil {
            print("error is nil")
        } else {
            print("error is not nil")
        }
    }
}
