//
//  PasswordSignInViewController.swift
//  trainee
//
//  Created by Anna Ovchynnykova on 11/13/19.
//  Copyright © 2019 Anna Ovchynnykova. All rights reserved.
//

import UIKit
import FirebaseUI
class PasswordSignInViewController: FUIPasswordSignInViewController{

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //setUpAuth()
        setUpDelegate()
        self.navigationItem.rightBarButtonItem = nil 
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
         emailTextField.text = UserDefaults.standard.string(forKey: "email") ?? ""
        
    }

    @IBAction func logInBtn() {
        guard let email = emailTextField.text else {return}
        guard let password = passwordTextField.text else {return}
        signIn(withDefaultValue: email, andPassword: password)
        
    
    }
 
    @IBAction func recoveryButton() {
        guard let email = emailTextField.text else {return}
        forgotPassword(forEmail: email)
    }
}

extension PasswordSignInViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func setUpDelegate() {
        emailTextField.delegate = self
        passwordTextField.delegate = self
    }
}
extension PasswordSignInViewController: FUIAuthDelegate {}



