//
//  PasswordRecoveryViewController.swift
//  trainee
//
//  Created by Anna Ovchynnykova on 11/14/19.
//  Copyright © 2019 Anna Ovchynnykova. All rights reserved.
//

import UIKit
import FirebaseUI

class PasswordRecoveryViewController: FUIPasswordRecoveryViewController {

    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTextField.delegate = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        emailTextField.text = UserDefaults.standard.string(forKey: "email") ?? ""
    }
    
    @IBAction func sendButton() {
        guard let email = emailTextField.text else {return}
        recoverEmail(email)
    }
    
}

extension PasswordRecoveryViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
