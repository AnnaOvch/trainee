import UIKit
import SwiftyGif
import FirebaseUI

class GifViewController: UIViewController {

    @IBOutlet weak var gifImageView: UIImageView!
    
    var completionHandler: Completion
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpGif()
   }
}

extension GifViewController: SwiftyGifDelegate {
    func gifDidStop(sender: UIImageView) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [unowned self] in
            self.completionHandler?()
        }
    }
    func setUpGif() {
        self.gifImageView.delegate = self
        guard let spashGifUrl = R.file.splashGif() else { return }
        guard let gifData = try? Data(contentsOf: spashGifUrl) else { return }
        guard let gifImage = try? UIImage(gifData: gifData, levelOfIntegrity: 1) else { return }
        self.gifImageView.setGifImage(gifImage, manager: .defaultManager, loopCount: 1)
    }
}
