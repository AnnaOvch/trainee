//
//  Types.swift
//  trainee
//
//  Created by Anna Ovchynnykova on 11/14/19.
//  Copyright © 2019 Anna Ovchynnykova. All rights reserved.
//

import Foundation
typealias Completion = (()->Void)?
