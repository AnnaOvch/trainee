//
//  SignUpViewController.swift
//  trainee
//
//  Created by Anna Ovchynnykova on 11/13/19.
//  Copyright © 2019 Anna Ovchynnykova. All rights reserved.
//

import UIKit
import FirebaseUI

class SignUpViewController: FUIPasswordSignUpViewController {

    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeVcDelegate()
        self.navigationItem.rightBarButtonItem = nil
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        emailTextField.text = UserDefaults.standard.string(forKey: "email") ?? ""
    }

    @IBAction func signUpBtn() {
        guard let email = emailTextField.text else {return}
        guard let name = nameTextField.text else {return}
        guard let password = passwordTextField.text else {return}
        signUp(withEmail: email, andPassword: password, andUsername: name)
    }
    
}
extension SignUpViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func makeVcDelegate() {
        passwordTextField.delegate = self
        nameTextField.delegate = self
        emailTextField.delegate = self
    }
}
extension SignUpViewController: FUIAuthDelegate {}
